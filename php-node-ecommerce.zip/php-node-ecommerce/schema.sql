-- Create database
CREATE DATABASE IF NOT EXISTS `php_node_ecommerce` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `php_node_ecommerce`;

-- Drop tables if they exist (clean setup)
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `products`;

-- Create products table
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `price` INT NOT NULL,
  `stock` INT NOT NULL DEFAULT 0,
  `image_url` TEXT NULL,
  `rating` DECIMAL(3,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create users table
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password_hash` VARCHAR(64) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `address` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create orders table
CREATE TABLE `orders` (
  `id` VARCHAR(50) PRIMARY KEY,
  `customer_name` VARCHAR(255) NOT NULL,
  `customer_email` VARCHAR(255) NOT NULL,
  `customer_phone` VARCHAR(50) NOT NULL,
  `customer_address` TEXT NOT NULL,
  `payment_method` VARCHAR(100) NOT NULL,
  `total_amount` INT NOT NULL,
  `order_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create order items table
CREATE TABLE `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(50) NOT NULL,
  `product_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `quantity` INT NOT NULL,
  `price` INT NOT NULL,
  `subtotal` INT NOT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed products data
INSERT INTO `products` (`id`, `name`, `category`, `description`, `price`, `stock`, `image_url`, `rating`) VALUES
(1, 'ZenSpace Mechanical Keyboard', 'Tech', 'A tactile, wireless hot-swappable mechanical keyboard featuring elegant wooden housing and custom muted switches for a premium typing experience.', 1500000, 9, 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=600&q=80', 4.80),
(2, 'Minimalist Wool Desk Mat', 'Accessories', 'Premium merino wool felt desk organizer mat to protect your workspace and add natural warmth and comfort to your daily routines.', 450000, 25, 'https://images.unsplash.com/photo-1616440347437-b1c73416efc2?auto=format&fit=crop&w=600&q=80', 4.60),
(3, 'Nordic Oak Headphone Stand', 'Accessories', 'Solid steam-bent oak wood stand with a matte powder-coated steel base, designed to display and hold premium audiophile headphones.', 650000, 8, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80', 4.90),
(4, 'Ergonomic Active Office Chair', 'Furniture', 'Lumbar-supporting, breathable mesh mesh chair with full adjustable armrests and seat depth, built for long creative sessions.', 3200000, 5, 'https://images.unsplash.com/photo-1580481072645-022f9a6dbf27?auto=format&fit=crop&w=600&q=80', 4.70),
(5, 'Aura Glass Water Carafe', 'Lifestyle', 'Hand-blown borosilicate glass carafe with a signature sphere cork lid, bringing minimal elegance to your desk hydration.', 280000, 20, 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80', 4.50),
(6, 'Muted Sage Water Bottle', 'Lifestyle', 'Double-walled vacuum insulated stainless steel bottle in a matte sage green finish. Keeps your beverages cold for 24 hours.', 390000, 18, 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80', 4.40),
(7, 'Lunar Eclipse Desk Lamp', 'Lighting', 'Sculptural dimmable LED lamp casting warm ambient light, inspired by lunar phases. Perfect for evening writing or wind-down routines.', 890000, 7, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=600&q=80', 4.80),
(8, 'Leather Desk Organizer Tray', 'Accessories', 'Hand-stitched full-grain leather tray to keep your keys, pens, and coins organized in one elegant place.', 320000, 15, 'https://images.unsplash.com/photo-1590244921253-447f35b31211?auto=format&fit=crop&w=600&q=80', 4.70),
(9, 'Amber Glass Soy Candle', 'Lifestyle', 'Hand-poured soy wax candle infused with notes of sandalwood, amber, and cedarwood in a minimalist glass jar.', 180000, 40, 'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=600&q=80', 4.50),
(10, 'Beechwood Analogue Desk Clock', 'Accessories', 'Silent sweeping hand quartz clock carved from natural solid beechwood, adding organic style to your desktop.', 420000, 10, 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80', 4.60);
