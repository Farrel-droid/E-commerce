document.addEventListener('DOMContentLoaded', () => {
    // -------------------------------------------------------------------------
    // 1. Search & Category Filters (Real-time, Client-Side)
    // -------------------------------------------------------------------------
    const searchInput = document.querySelector('.search-input');
    const searchForm = document.querySelector('.search-form');
    const productGrid = document.querySelector('.product-grid');
    const noProductsEmptyState = document.getElementById('no-products-empty-state');
    const productCards = document.querySelectorAll('.product-card');
    const categoryChips = document.querySelectorAll('.category-chip');
    
    let currentCategory = '';
    
    // Initialize currentCategory based on active chip
    const activeChip = document.querySelector('.category-chip.active');
    if (activeChip) {
        const text = activeChip.textContent.trim();
        currentCategory = (text === 'All Items') ? '' : text;
    }
    
    // Search input event listener
    if (searchInput && productGrid) {
        // Prevent form submit reloading page on search input submit
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
            });
        }
        
        searchInput.addEventListener('input', () => {
            filterProducts();
        });
    }
    
    // Category chips click listener
    if (categoryChips.length && productGrid) {
        categoryChips.forEach(chip => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Update active state class on chips
                categoryChips.forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                
                const text = chip.textContent.trim();
                currentCategory = (text === 'All Items') ? '' : text;
                
                filterProducts();
            });
        });
    }
    
    // Clear filters button
    const clearFiltersBtn = document.getElementById('clear-filters-btn');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            categoryChips.forEach(c => {
                if (c.textContent.trim() === 'All Items') {
                    c.classList.add('active');
                } else {
                    c.classList.remove('active');
                }
            });
            currentCategory = '';
            filterProducts();
        });
    }
    
    function filterProducts() {
        const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
        let visibleCount = 0;
        
        productCards.forEach(card => {
            const name = card.getAttribute('data-name') || '';
            const category = card.getAttribute('data-category') || '';
            const description = card.getAttribute('data-description') || '';
            
            const matchesSearch = !query || name.includes(query) || description.includes(query);
            const matchesCategory = !currentCategory || category === currentCategory.toLowerCase();
            
            if (matchesSearch && matchesCategory) {
                card.style.display = 'flex';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });
        
        // Update section title text
        const sectionTitleText = document.getElementById('section-title-text');
        if (sectionTitleText) {
            let titleHTML = '';
            if (query) {
                titleHTML = `Search Results for '${escapeHTML(query)}'`;
            } else if (currentCategory) {
                titleHTML = escapeHTML(currentCategory);
            } else {
                titleHTML = 'Curated Collection';
            }
            titleHTML += `<p class="section-subtitle">Premium essentials designed to elevate your workspace and daily life.</p>`;
            sectionTitleText.innerHTML = titleHTML;
        }
        
        // Show or hide empty state
        if (visibleCount === 0) {
            if (noProductsEmptyState) noProductsEmptyState.style.display = 'block';
            if (productGrid) productGrid.style.display = 'none';
        } else {
            if (noProductsEmptyState) noProductsEmptyState.style.display = 'none';
            if (productGrid) productGrid.style.display = 'grid';
        }
        
        // Update address bar parameters without reloading
        const url = new URL(window.location);
        if (currentCategory) {
            url.searchParams.set('category', currentCategory);
        } else {
            url.searchParams.delete('category');
        }
        if (query) {
            url.searchParams.set('search', query);
        } else {
            url.searchParams.delete('search');
        }
        window.history.replaceState({}, '', url);
    }
    
    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }

    // -------------------------------------------------------------------------
    // 2. AJAX Cart Removal
    // -------------------------------------------------------------------------
    const removeButtons = document.querySelectorAll('.btn-remove');
    removeButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const id = btn.getAttribute('data-id');
            const cartItem = btn.closest('.cart-item');
            
            if (!id || !cartItem) return;
            
            // Disable button interaction during fetch request
            btn.style.pointerEvents = 'none';
            btn.style.opacity = '0.5';
            
            fetch(`cart.php?action=remove&id=${id}&ajax=1`)
                .then(response => {
                    if (!response.ok) throw new Error('Network response error');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        // Smooth removal animation
                        cartItem.style.transition = 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)';
                        cartItem.style.opacity = '0';
                        cartItem.style.transform = 'translateY(15px)';
                        
                        setTimeout(() => {
                            cartItem.remove();
                            
                            // Update cart counter in header badge
                            const cartCounter = document.getElementById('cart-counter');
                            if (cartCounter) {
                                cartCounter.textContent = data.cart_count;
                            }
                            
                            // Update summary box prices
                            const summaryBox = document.querySelector('.summary-box');
                            if (summaryBox) {
                                const rows = summaryBox.querySelectorAll('.summary-row');
                                if (rows.length >= 3) {
                                    // Row 0 is Subtotal, Row 2 is Total Amount
                                    rows[0].querySelector('span:last-child').textContent = data.subtotal_formatted;
                                    rows[2].querySelector('span:last-child').textContent = data.subtotal_formatted;
                                }
                            }
                            
                            // Toggle empty cart layout if count drops to 0
                            if (data.cart_count === 0) {
                               const emptyCartState = document.getElementById('empty-cart-state');
                               const cartLayoutContainer = document.getElementById('cart-layout-container');
                               const clearCartBtn = document.getElementById('clear-cart-btn');
                               
                               if (emptyCartState) emptyCartState.style.display = 'block';
                               if (cartLayoutContainer) cartLayoutContainer.style.display = 'none';
                               if (clearCartBtn) clearCartBtn.style.display = 'none';
                            }
                        }, 300);
                    } else {
                        console.error('AJAX Cart error:', data.error);
                        btn.style.pointerEvents = 'auto';
                        btn.style.opacity = '1';
                    }
                })
                .catch(err => {
                    console.error('Failed to remove cart item:', err);
                    btn.style.pointerEvents = 'auto';
                    btn.style.opacity = '1';
                });
        });
    });

    // -------------------------------------------------------------------------
    // 3. Form Validation (Custom JS inline warning messages)
    // -------------------------------------------------------------------------
    
    // Helper validation functions
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showError(inputElement, message) {
        // Reset any existing error styling first
        clearError(inputElement);
        
        // Create error description element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.style.color = 'var(--danger)';
        errorDiv.style.fontSize = '12px';
        errorDiv.style.marginTop = '6px';
        errorDiv.style.fontWeight = '500';
        errorDiv.innerText = message;
        
        // Highlight inputs with invalid borders
        inputElement.classList.add('is-invalid');
        inputElement.style.borderColor = 'var(--danger)';
        inputElement.style.boxShadow = '0 0 0 3px rgba(192, 108, 108, 0.1)';
        
        // Insert after parent wrapper if nested or directly after the input
        inputElement.parentNode.insertBefore(errorDiv, inputElement.nextSibling);
    }
    
    function clearError(inputElement) {
        inputElement.classList.remove('is-invalid');
        inputElement.style.borderColor = '';
        inputElement.style.boxShadow = '';
        
        const nextEl = inputElement.nextSibling;
        if (nextEl && nextEl.className === 'error-message') {
            nextEl.remove();
        }
    }
    
    // Global real-time check to remove invalid style while typing
    document.addEventListener('input', (e) => {
        const target = e.target;
        if (target && (target.classList.contains('form-control') || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
            clearError(target);
        }
    });
    
    // A. Login Form Validation
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            // Remove previous errors
            loginForm.querySelectorAll('.error-message').forEach(el => el.remove());
            loginForm.querySelectorAll('.form-control').forEach(el => {
                el.style.borderColor = '';
                el.style.boxShadow = '';
            });
            
            let isValid = true;
            const email = document.getElementById('email');
            const password = document.getElementById('password');
            
            if (email) {
                if (!email.value.trim()) {
                    showError(email, 'Email address is required.');
                    isValid = false;
                } else if (!validateEmail(email.value.trim())) {
                    showError(email, 'Please enter a valid email address.');
                    isValid = false;
                }
            }
            
            if (password) {
                if (!password.value) {
                    showError(password, 'Password is required.');
                    isValid = false;
                }
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // B. Register Form Validation
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            // Remove previous errors
            registerForm.querySelectorAll('.error-message').forEach(el => el.remove());
            registerForm.querySelectorAll('.form-control').forEach(el => {
                el.style.borderColor = '';
                el.style.boxShadow = '';
            });
            
            let isValid = true;
            
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const password = document.getElementById('password');
            const address = document.getElementById('address');
            
            if (name) {
                if (!name.value.trim()) {
                    showError(name, 'Full name is required.');
                    isValid = false;
                }
            }
            
            if (email) {
                if (!email.value.trim()) {
                    showError(email, 'Email address is required.');
                    isValid = false;
                } else if (!validateEmail(email.value.trim())) {
                    showError(email, 'Please enter a valid email address.');
                    isValid = false;
                }
            }
            
            if (phone) {
                if (!phone.value.trim()) {
                    showError(phone, 'Phone number is required.');
                    isValid = false;
                } else {
                    const cleanedPhone = phone.value.trim().replace(/[+\-\s()]/g, '');
                    if (!/^\d{8,15}$/.test(cleanedPhone)) {
                        showError(phone, 'Please enter a valid phone number (8-15 digits).');
                        isValid = false;
                    }
                }
            }
            
            if (password) {
                if (!password.value) {
                    showError(password, 'Password is required.');
                    isValid = false;
                } else if (password.value.length < 6) {
                    showError(password, 'Password must be at least 6 characters.');
                    isValid = false;
                }
            }
            
            if (address) {
                if (!address.value.trim()) {
                    showError(address, 'Shipping address is required.');
                    isValid = false;
                }
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // C. Checkout Form Validation
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', (e) => {
            // Remove previous errors
            checkoutForm.querySelectorAll('.error-message').forEach(el => el.remove());
            checkoutForm.querySelectorAll('.form-control').forEach(el => {
                el.style.borderColor = '';
                el.style.boxShadow = '';
            });
            
            let isValid = true;
            
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const address = document.getElementById('address');
            
            if (name) {
                if (!name.value.trim()) {
                    showError(name, 'Full name is required.');
                    isValid = false;
                }
            }
            
            if (email) {
                if (!email.value.trim()) {
                    showError(email, 'Email address is required.');
                    isValid = false;
                } else if (!validateEmail(email.value.trim())) {
                    showError(email, 'Please enter a valid email address.');
                    isValid = false;
                }
            }
            
            if (phone) {
                if (!phone.value.trim()) {
                    showError(phone, 'Phone number is required.');
                    isValid = false;
                } else {
                    const cleanedPhone = phone.value.trim().replace(/[+\-\s()]/g, '');
                    if (!/^\d{8,15}$/.test(cleanedPhone)) {
                        showError(phone, 'Please enter a valid phone number (8-15 digits).');
                        isValid = false;
                    }
                }
            }
            
            if (address) {
                if (!address.value.trim()) {
                    showError(address, 'Shipping address is required.');
                    isValid = false;
                }
            }
            
            // Validate radio buttons
            const paymentMethods = checkoutForm.querySelectorAll('input[name="payment_method"]');
            let paymentSelected = false;
            paymentMethods.forEach(radio => {
                if (radio.checked) paymentSelected = true;
            });
            
            if (!paymentSelected) {
                const radioGroup = checkoutForm.querySelector('.radio-group');
                if (radioGroup) {
                    // Check if error is already present under radio group
                    const nextEl = radioGroup.nextSibling;
                    if (!nextEl || nextEl.className !== 'error-message') {
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'error-message';
                        errorDiv.style.color = 'var(--danger)';
                        errorDiv.style.fontSize = '12px';
                        errorDiv.style.marginTop = '6px';
                        errorDiv.style.fontWeight = '500';
                        errorDiv.innerText = 'Please select a payment method.';
                        radioGroup.parentNode.insertBefore(errorDiv, radioGroup.nextSibling);
                    }
                }
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
        
        // Remove payment method error when radio is clicked
        const radioCards = checkoutForm.querySelectorAll('.radio-card');
        radioCards.forEach(card => {
            card.addEventListener('click', () => {
                const radioGroup = checkoutForm.querySelector('.radio-group');
                if (radioGroup && radioGroup.nextSibling && radioGroup.nextSibling.className === 'error-message') {
                    radioGroup.nextSibling.remove();
                }
            });
        });
    }
});
